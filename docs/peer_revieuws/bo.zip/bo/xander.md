I really enjoyed working with Xander. He is very helpfull and participating.

Rubric	- -	-	+/-	+	++
Discipline & Work Ethic			        ++
Helpfulness					            ++
Asks for feedback				        +/-	
Gives feedback					        +
Concentration/focus				        +/-
I give 50 out of 100 points to Xander.

Extra feedback:

Sometimes we were distracted as a group, what made it very fun but also slowed our progress.