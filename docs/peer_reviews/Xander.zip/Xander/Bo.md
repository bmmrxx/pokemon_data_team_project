Samen werking tussen elkaar ging goed, Bo had nog niet de ervaring met cloud maar heeft zeker haar steentje bijgedragen.

Rubric	- -	-	+/-	+	++
Discipline & Work Ethic					++
Helpfulness					            ++
Asks for feedback					    +
Gives feedback					        +
Concentration/focus					    +/-
50 van de 100 punten voor Bo.
