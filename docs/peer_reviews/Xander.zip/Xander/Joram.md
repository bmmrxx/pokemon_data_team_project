Zoals bijna elke week kunnen wij gewoon goed samen werken, zeker leuk om samen de nieuwe ervaring van cloud te gebruiken bij het project.

Rubric	- -	-	+/-	+	++
Discipline & Work Ethic					++
Helpfulness					            ++
Asks for feedback					    +
Gives feedback					        ++
Concentration/focus					    +
50 punten van de 100 voor Joram!
